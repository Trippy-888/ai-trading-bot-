
import time
import requests
import os

FMP_API_KEY = os.getenv("FMP_API_KEY")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

ASSETS = ["XAU/USD", "XAG/USD", "GBP/USD"]
THRESHOLD_MOVE = 1.0  # percent move to consider a "big move"

def fetch_price(symbol):
    url = f"https://financialmodelingprep.com/api/v3/quote/{symbol}?apikey={FMP_API_KEY}"
    try:
        response = requests.get(url)
        data = response.json()
        return float(data[0]["price"])
    except Exception as e:
        print(f"Error fetching price for {symbol}: {e}")
        return None

def send_telegram_alert(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    data = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "HTML"
    }
    try:
        requests.post(url, data=data)
    except Exception as e:
        print(f"Telegram send error: {e}")

def scan_market():
    print("Scanning market...")
    for symbol in ASSETS:
        price = fetch_price(symbol.replace("/", ""))
        if price:
            # Fake signal condition for now
            if price % 2 < 0.3:
                send_telegram_alert(f"🚨 Signal on <b>{symbol}</b> - Current Price: {price}")

if __name__ == "__main__":
    while True:
        scan_market()
        time.sleep(300)  # 5 minutes
